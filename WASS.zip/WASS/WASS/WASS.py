#!/usr/bin/env python
#
# Author  : WASS Team
# WASS-framework - Web application scanner


#modules importing
import os
import sys
import time
import hashlib
import datetime
sys.path.append('core/')
from gost import *
from coder import *
from update import *
from banner import *
from command import *
sys.path.append('modules/')
from hashc import *
from hashk import * 
from hashm import * 
from hashs import *
from hashz import *
from xssy import *
from info import *
from sqldork import *
from adm import *
from clickjack import *
from who import *
from por import *
from rce import *
from sqll import *
from iplocator import *
from reverse import *
from header import *


try:
	from termcolor import colored, cprint

except ImportError as ie:
	print(str(ie))

def clear():
    if system() == 'Linux':
        os.system("clear")
    if system() == 'Windows':
        os.system('cls')
        os.system('color a')
    else:
        pass

class WASSMain(object):
	   
	   def joker(self):
		__version__ = '1.0.4'
		__author__ = "WASS Team"
		__Github__ = "https://github.com/WASS-TEAM"
		__Twitter__ = "https://twitter.com/WASS-Team"
		__Channel__ = "https://www.youtube.com/"
		__Facebook__ = "https://facebook.com/WASSTEAM"
		__date__ = datetime.datetime.now()
		__tools__ = "15"

                try:
		    github = raw_input("\n\033[92m[\033[91mWASS\033[92m]\033[93m$>")

		    if github == 'exit':
		    	print '\033[1;91mThanks for Usage \033[96mWASSframework !'
		    	sys.exit(0)

		    if github == 'clear':
			    os.system('clear')
			    Banner()
			    GostBanner()
			    return WASS.joker()

		    if github == 'version':
		    	os.system('clear')
		    	Banner()
		    	GostBanner()
		        print("\033[41mVersion: " + colored(__version__, 'white'))
		        return WASS.joker()


		    if github == 'banner':
		         Banner()
		         GostBanner()
		         return WASS.joker()

		    if github == 'xss':
				 xssvu()
				 return WASS.joker()

		    if github == 'whois':
		    	 whois()
		    	 return WASS.joker()

		    if github == 'iplocator':
		         iploc()
		         return WASS.joker()

		    if github == 'dork':
		         sdork()
		         return WASS.joker()

		    if github == 'rce':
		    	 rceScan()
		    	 return WASS.joker()

		    if github == 'sql':
		         sqlvuln()
		         return WASS.joker()

		    if github == 'info':
		         infor()
		         return WASS.joker() 

		    if github == 'admin':
		         adminv()
		         return WASS.joker()

		    if github == 'clickjack':
		    	 clickjack()
		    	 return WASS.joker()

		    if github == 'md5':
		    	 md5hash()
		    	 return WASS.joker()

		    if github == 'sha1':
				 sha1hash()
				 return WASS.joker()

		    if github == 'show modules':
			    modules()
			    return WASS.joker()

		    if github == 'update':
		         WASSf()
		         return WASS.joker()


		    if github == 'SHA256':
				 SHA256hash()
				 return WASS.joker()

		    if github == 'SHA384':
				 SHA384hash()
				 return WASS.joker()

		    if github == 'SHA512':
				 SHA512hash()
				 return WASS.joker()

		    if github == 'author':
			    Gostauto()
			    return WASS.joker()

		    if github == 'help':
		    	cmd()
		    	return WASS.joker()

		    elif github == 'port':
			    port()
			    return WASS.joker()

		    elif github == 'reverse':
			    revip()
			    return WASS.joker()

		    elif github == 'header':
			    head()
			    return WASS.joker()

                except KeyboardInterrupt:
                        cprint("\n[!] You Press Ctrl + C! To Quit.", 'red')
                        sys.exit(1)

                except:
                        pass

def banner():
    Banner()
    GostBanner()


if __name__ == "__main__":
	Banner()
	GostBanner()
	WASS = WASSMain()
	WASS.joker()
